<div class="wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-sm-12">
                        <div style="margin: 10px;">
                            <?php echo $this->session->flashdata('notification_password')?>
                        </div>
                    </div>
                </div>
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h4 class="page-title m-0">Tes Big Five 3</h4>
                                </div>
                                <div class="col-md-4">
                                    <div class="float-right d-none d-md-block">
                                        <!-- <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-settings mr-1"></i> Settings
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Separated link</a>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

                <!-- <div class="row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-primary mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Orders</h6>
                                    <h4 class="mb-3 mt-0 float-right">1,587</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +11% </span> <span class="ml-2">From previous period</span>
                                </div>
                                
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-cube-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1447</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-info mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Revenue</h6>
                                    <h4 class="mb-3 mt-0 float-right">$46,785</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-danger"> -29% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-buffer h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : $47,596</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-pink mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Average Price</h6>
                                    <h4 class="mb-3 mt-0 float-right">15.9</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-primary"> 0% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-tag-text-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 15.8</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-success mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Product Sold</h6>
                                    <h4 class="mb-3 mt-0 float-right">1890</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +89% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-briefcase-check h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1776</p>
                            </div>
                        </div>
                    </div>
                </div>   -->
                <!-- end row -->

                <div class="row">
                    <div class="col-xl-8">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="mt-0 ">Tentang Big Five (OCEAN) Personality Test</h3>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div style="text-align:center;margin: 20px;">
                                            <img src="<?php echo base_url() ?>assets/images/ocean1.png" alt="holland1" style="height:20vw;">
                                        </div>

                                        <p class="font-14">Mungkin ada yang sedang berpikir tentang apa yang akan mereka lakukan dalam hidup (I’m looking at you, Quarter Life Crisis club member!). Mungkin ada dari kalian yang masih bertanya-tanya, “Aku tuh, sebenarnya cocok ngapain, sih?” atau mungkin malah merasa kalau apa yang kamu lakukan itu kayak, gak cocok aja gitu sama diri kamu sendiri.</p>
                                        <p class="font-14">Well, aku rasa aku punya sesuatu yang mungkin bisa menjadi pencerah kalian dalam mencari jawaban tersebut! Izinkan aku memperkenalkan Big Five Personality Test (OCEAN) pada kalian. Eh, ocean? Laut? Oke, oke, daripada bingung mari kita langsung saja membahas Big Five Personality Test!</p>
                                        
                                        <h3>Apa Itu Big Five Personality Test?</h3>
                                        <p class="font-14">Jadi, dahulu kala, banyak psikolog yang mencoba nge-list kepribadian seseorang tuh mencakup apa aja. Psikolog bernama Gordon Allport dan Henry Odbert berteori bahwa karena orang-orang menyadari adanya perbedaan kepribadian, mereka bakal membuat sebuah kata untuk menjelaskan kepribadian tersebut.</p>
                                        <p class="font-14">Misalnya, ‘kan lebih enak buat nyebut “Dia orangnya periang” daripada “Dia orangnya suka jalan-jalan, kalau ketemu orang pasti selalu lagi senang, dan senyumnya bertahan sepanjang hari”.</p>
                                        <p class="font-14">Lalu pada tahun 1936, mereka berhasil menemukan beberapa personality trait yang menggambarkan kepribadian seseorang, yah sekitaran 4000-an gitu.</p>
                                        <p class="font-14">Terus ya, orang manapun pasti mikir “Buset banyak banget??”. Maka dari itu, seorang Psikolog bernama Raymond Cattell dan koleganya pada tahun 1940-an menindaklanjuti apa yang sudah ditemukan oleh Gordon Allport. Dan mereka berhasil menyederhanakan 4000 tadi menjadi 16 personality traits.</p>
                                        <p class="font-14">Tidak berhenti sampai di situ, beberapa psikolog menganalisa lagi 16 tadi dan menemukan bahwa sebenarnya masih bisa dibuat lebih sederhana lagi, menjadi lima aspek saja.</p>
                                        <p class="font-14">Lewis Goldberg, di antara psikolog tadi, benar-benar mendukung lima aspek ini. Kerjaan Lewis lalu diperluas oleh psikolog bernama McCrae dan Costa, yang mana kemudian menjadikan model Big Five yang kita tahu sekarang menjadi–bisa dibilang–resmi.</p>
                                        <p class="font-14">Big Five yang dimaksud adalah: Openness to experience, Conscientiousness, Extraversion, Agreeableness, dan Neuroticism. Kalau nama lima aspek tersebut disingkat, kita mendapatkan kata OCEAN. Ini untuk mempermudah orang untuk mengingatnya.</p>
                                        <p class="font-14">Namun kurasa tidak dibuat singkatan pun, OCEAN ini akan gampang diingat karena model tes kepribadian ini sangat populer, terlepas dari budaya dan lokasi tempat orang-orang mengambil tes ini.</p>
                                        
                                        <h3>OCEAN</h3>
                                        <p class="font-14">Masing-masing dari aspek pada Big Five ini merupakan sebuah spektrum, yang berarti bahwa hasil dari tes ini menandakan seseorang berada somewhere in between two extreme ends.</p>
                                        <p class="font-14">Misalnya, pada aspek Openness, hasilmu nanti bukan berarti antara terbuka akan hal baru atau sama sekali tidak menerima ide baru. Hasil dari Openness nanti menandakan seberapa terbukanya kamu terhadap hal baru dan bagaimana responmu terhadapnya.</p>
                                        <p class="font-14">Hasil dari OCEAN tidak bisa dilihat sendiri-sendiri, kamu harus memahaminya secara menyeluruh. Kamu sebaiknya memahami benar-benar apa yang dimaksud dari tinggi-rendahnya skor pada sebuah aspek. Kamu bisa membaca tentang hal tersebut di sini.</p>
                                        
                                        <h3>Hal-hal yang Patut Diingat</h3>
                                        <p class="font-14">Walaupun OCEAN ini sangat praktis, perlu diingat bahwa OCEAN ini bersifat deskriptif. Sederhananya gini. Big Five ‘kan punya lima aspek utama. Masing masing aspek merupakan spektrum dengan dua ujung yang bertolak belakang. Terus nanti, setelah tes, kamu bakal dapat skor masing-masing aspek. Skor O berapa, skor C berapa, dst.</p>
                                        <p class="font-14">Nah, OCEAN bakal menggunakan hasil tesmu tadi untuk memberitahumu, apa sih maksudnya dari skor O yang tinggi, skor C yang rendah, dst. Agak berbeda dengan MBTI. Contohnya ketika kamu mendapatkan ESFJ (seperti aku) untuk tes MBTI-mu, kamu bakal membaca tentang bagaimana sih, seorang ESFJ itu.</p>
                                        <p class="font-14">Lain halnya dengan OCEAN yang hanya memiliki “meteran” kepribadian terus kamu sederhananya “ngukur” kepribadianmu pake “meteran” yang sudah disediakan.</p>
                                        <p class="font-14">Kalau mau diumpamakan ya, tes OCEAN itu kayak kamu dikasih Lego tapi eceran. Kamu dapatnya satu-satu terus kamu pasang sendiri menjadi sesuatu yang sesuai dengan apa yang kamu butuhkan. Kalau MBTI, kamu beli Lego-nya udah jadi, udah jelas dia bentuknya apa.</p>
                                        <p class="font-14">OCEAN juga sempat dikritisi karena terlalu luas. Kibeom Lee dan Michael Ashton mengembangkan sebuah model baru yang bernama HEXACO. Model ini tetap mengandung aspek dari OCEAN hanya saja mereka menambahkan satu yang baru, yaitu Honesty-Humility, yang merupakan tolak ukur sejauh apa seseorang mengedepankan hal-hal tentang orang lain daripada dirinya. Mirip dengan altruisme ya.</p>

                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/pnwPYGN_BAE?feature=oembed"></iframe>
                                        </div> 
                                        <div class="m-b-30" style="text-align:center;">Tes Holland atau Tes Big FIve atau OCEAN</div>
                                        
                                        <p class="font-14">Siap Untuk Mencoba Tes OCEAN?</p>
                                        <p class="font-14">Lalu, hampir sama dengan tes-tes kepribadian pada umumnya, jangan menganggap satu hasil tes OCEAN dapat menggambarkan kepribadianmu selamanya. Hasil tes OCEAN orang-orang sepanjang hidup dapat berubah, walaupun hanya sedikit. Maka dari itu, kita sebaiknya melihat hasil tes ini sebagai tools untuk kita dalam mengembangkan diri.</p>
                                        <p class="font-14">Jangan melihat hasil tes ini sebagai pembatas potensi diri, namun anggap hasil tes ini sebagai kesempatanmu untuk menjadi orang yang lebih baik.</p>
                                        <p class="font-14">Oh iya! Satu lagi. Ketika mengambil tes OCEAN, jangan berusaha untuk menjawab pertanyaan yang menurutmu “lebih baik” di mata masyarakat ya. Jawablah sesuai dengan apa yang menurutmu cocok dengan dirimu! Semoga hasil Tes OCEAN bisa membantumu dalam menghadapi Quarter Life Crisis ya!</p>
                                        <p class="font-14">Jika kamu masih merasa kebingungan mengenai Quarter Life Crisis, tonton video ini sebentar!</p>
                                        
                                        <p class="font-14">Akhir kata, semoga tulisanku ini berguna ya!</p>

                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/jnwOBr7DtKA?feature=oembed"></iframe>
                                        </div> 
                                        <div class="m-b-30" style="text-align:center;">Tes Holland atau Tes Big FIve atau OCEAN</div>

                                        <h6>References</h6>
                                        <p class="font-14">T., E. (2020, January 10). History of the Big 5: Why This Online Psychometric Test Packs a Punch. Retrieved from retorio: https://www.retorio.com/blog/big-5-history-psychometric-test</p>
                                        <p class="font-14">Lim, A (2020, June 15). The big five personality traits. Simply Psychology. https://www.simplypsychology.org/big-five-personality.html</p>
                                        <p class="font-14">Dilansir dari https://www.satupersen.net/blog/big-5-personality</p>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>