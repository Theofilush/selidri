<div class="wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-sm-12">
                        <div style="margin: 10px;">
                            <?php echo $this->session->flashdata('notification_password')?>
                        </div>
                    </div>
                </div>
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h4 class="page-title m-0">Tes Big Five 2</h4>
                                </div>
                                <div class="col-md-4">
                                    <div class="float-right d-none d-md-block">
                                        <!-- <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-settings mr-1"></i> Settings
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Separated link</a>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

                <!-- <div class="row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-primary mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Orders</h6>
                                    <h4 class="mb-3 mt-0 float-right">1,587</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +11% </span> <span class="ml-2">From previous period</span>
                                </div>
                                
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-cube-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1447</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-info mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Revenue</h6>
                                    <h4 class="mb-3 mt-0 float-right">$46,785</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-danger"> -29% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-buffer h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : $47,596</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-pink mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Average Price</h6>
                                    <h4 class="mb-3 mt-0 float-right">15.9</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-primary"> 0% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-tag-text-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 15.8</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-success mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Product Sold</h6>
                                    <h4 class="mb-3 mt-0 float-right">1890</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +89% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-briefcase-check h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1776</p>
                            </div>
                        </div>
                    </div>
                </div>   -->
                <!-- end row -->

                <div class="row">
                    <div class="col-xl-8">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="mt-0 ">Big Five Personality Test: Memanfaatkan Hasil Tes OCEAN</h3>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div style="text-align:center;margin: 20px;">
                                            <img src="<?php echo base_url() ?>assets/images/ocean2.png" alt="holland1" style="height:20vw;">
                                        </div>
                                        <p class="font-14">Sekarang kita akan berkenalan dengan tes Big Five, tes ini sebagai tools kita untuk dapat berkembang dan menemukan potensi yang ada pada diri sendiri. Pada setiap tes kepribadian yang kita temukan itu tidak berarti bahwa hasil tes menjadi penentu kita sebagai orang yang seperti apa. Tentu saja kita ini memiliki kepribadian yang terus berkembang pada diri kita sendiri, sehingga kepribadian kita akan terus berubah secara dinamis mengikut umur. Ada berbagai kemungkinan kita dapat mengubah sifat kita, ada juga sifat yang melekat pada diri kita. Diperlukan tools atau alat yang dapat mengukur bagaimana sifat kita dapat mempunyai potensi lebih produktif.</p>
                                        
                                        <h3>OCEAN Test Result: What to Do</h3>
                                        <p class="font-14">Oke, back to the OCEAN. Mungkin kamu pernah mengikuti tes ini dan mendapatkan hasilnya, terus kamu bertanya-tanya. Waduh, kalau skor Openness-ku rendah berarti aku close minded? Kalau Agreeableness-ku tinggi apakah aku orangnya gak bisa bilang ‘tidak’?</p>
                                        <p class="font-14">Walau Tes OCEAN ini sudah diakui secara global dan disenangi karena kesederhanaannya, ada kalanya orang-orang kurang bisa menangkap maksud dari hasil tes mereka dan gagal mengembangkan dirinya menuju arah yang lebih cocok dengan kepribadiannya.</p>
                                        <p class="font-14">Maka dari itu, ku harap tulisan ini bisa membantumu dalam memahami dirimu melalui hasil tes OCEAN!</p>
                                        
                                        <h3>OCEAN Test Result</h3>
                                        <h5>Openness</h5>
                                        <p class="font-14">Kalau penjelasan bahwa Openness hanya tentang ‘keterbukaan’ mungkin kurang informatif buatmu, berarti kamu membutuhkan breakdown lagi dari aspek Openness ini. Openness memiliki ciri intellectance (filosofis dan intelektual) serta unconventionality (imajinatif, otonom, dan ‘bebas’). Sederhananya, ada aspek ilmu ada aspek kreativitas di sini.</p>
                                        <p class="font-14">Ini berarti bahwa dengan melihat skor Openness-mu, kamu dapat menentukan lingkungan seperti apa yang cocok denganmu. Contohnya, ketika Openness tinggi, maka kamu pada dasarnya sudah gak cocok dengan hal-hal yang terlalu kaku dan stagnan. Kamu lebih cocok berada di lingkungan yang dinamis, yang gak terlalu mengekang.</p>
                                        <p class="font-14">Hal ini juga dapat membuatmu aware akan lingkungan sosialmu. Apakah ada orang-orang yang kamu udah kenal lama tapi kok gak cocok, ada juga yang baru kenal sebentar tapi udah kayak match made in heaven. Kemungkinan besar, kepribadian kalian cocok satu sama lain atau melengkapi satu sama lain.</p>
                                        <p class="font-14">So, ketika kamu melihat skor Openness-mu, jangan membatasi dirimu seperti “Oh skorku tinggi berarti aku gak boleh kerja kantoran yang gitu-gitu aja”, tapi ubahlah hasil tersebut menjadi kesempatan untuk berkembang seperti “Oh, skorku tinggi, berarti aku suka dan cocok menjadi orang yang mengajukan ide baru di lingkunganku.”</p>
                                        <p class="font-14">Orang dengan Openness rendah mungkin merasa cukup sulit untuk menerima hal-hal baru, walaupun sesungguhnya gak seburuk itu untuk menyapa ide dan pandangan baru. Jika kamu merasa demikian, mungkin ada baiknya kamu belajar untuk lebih open-minded!</p>
                                        
                                        <h5>Conscientiousness</h5>
                                        <p class="font-14">Conscientiousness merupakan aspek yang paling terkait dengan performa dalam dunia kerja. Conscientiousness dapat diproyeksikan dalam tiga aspek yang lebih detail, yaitu achievement oriented (pekerja keras dan tidak gampang menyerah), dependability (bertanggung jawab dan berhati-hati), dan orderliness (teratur dan terorganisir).</p>
                                        <p class="font-14">Uh.. ini gak aku banget. Tapi, aku gak melihat ini sebagai batasan buat diriku. Aku dulu sempat mikir, “Aku orangnya emang ceroboh dan gak teratur, gak bakal sukses.”</p>
                                        <p class="font-14">But no! Akhirnya aku menggunakan fakta bahwa aku memang gak memiliki skor tinggi dalam conscientiousness ini sebagai motivasiku. Aku jadi suka membeli planner atau membuat jadwal, hanya untuk memberiku rasa aman bahwa jadwalku itu teratur. Padahal ya gak, toh emang dasarnya aku ceroboh dan suka lupa hehe.</p>
                                        <p class="font-14">Aku menjadikan hal tersebut sebagai nilai plus, bahwa aku orangnya fleksibel. Bahwa aku bisa cepat beradaptasi dari satu jadwal ke jadwal lain kalau memang terjadi keadaan darurat. It’s like, emang udah terbiasa sama ketidakteraturan jadi aku memiliki kemampuan untuk beradaptasi lebih cepat.</p>
                                        <p class="font-14">Tapi yah, kalau dibilang pengen bisa teratur dan rapi, aku juga mau sih, hehe. That’s why, kamu juga harus selalu bisa menangkap hal yang baik dari hasil Tes OCEAN-mu.</p>
                                        <p class="font-14">Conscientiousness tinggi? Do things that requires tidiness and orderliness</p>
                                        <p class="font-14">Conscientiousness rendah? Don’t worry, you’re flexible!</p>
                                        
                                        <p class="font-14">Fokus ke apa yang bisa kamu lakukan dengan skormu dibandingkan dengan apa yang gak bisa kamu lakuin. Tapi kalau kamu memang ingin berusaha mengubah kebiasaanmu, coba tonton video ini!</p>

                                                <div class="embed-responsive embed-responsive-16by9">
                                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/jnwOBr7DtKA?feature=oembed"></iframe>
                                                </div> 
                                                <div class="m-b-30" style="text-align:center;">Tes Holland atau Tes Big FIve atau OCEAN</div>
                                                
                                        <h5>Extraversion</h5>
                                        <p class="font-14">Extraversion adalah tentang bagaimana seseorang dalam aspek socially oriented (ramah dan suka berteman), surgent (dominan dan ambisius), dan aktif (suka bertualang dan asertif).</p>
                                        <p class="font-14">Perlu kamu ingat bahwa ekstrovert tidak selalu lebih baik dari introvert. It’s case by case. Ketika kamu sadar bahwa kamu orangnya ekstrovert, manfaatkan hal tersebut untuk dirimu, misalnya mencari relasi, menjalin networking di lingkungan kerja, dll. Introvert pun demikian, kamu dapat memanfaatkan kepribadianmu untuk menjadi follower yang baik, menjadi orang “di balik layar”, dll.</p>
                                        <p class="font-14">Introvert juga bisa ambisius dan ramah, loh! Bukan berarti ketika kamu introvert maka kamu “anti sosial” atau “tidak bisa ngomong’. No! Itu omong kosong.</p>
                                        <p class="font-14">Jangan paksakan dirimu untuk menjadi ekstrovert jika memang kamu tahu benar kamu adalah seorang introvert.</p>
                                        
                                        <h5>Agreeableness</h5>
                                        <p class="font-14">Pernah gak sih ketemu orang yang kayaknya disukai semua orang? Baik ke semua orang, ramah, ceria, pokoknya everybody’s friend banget! Aku rasa orang-orang seperti itu pasti Agreeableness-nya tinggi, karena agreeableness itu tentang cooperative (percaya orang lain dan peduli) dan juga likeable (ceria, lembut, dan bersikap baik).</p>
                                        <p class="font-14">Berarti, ketika agreeableness-mu tinggi, kamu lebih natural untuk berteman dan mendapatkan hati orang lain. Tapi, ini gak berarti kalau kamu yang memiliki skor Agreeableness rendah lantas gak bisa bergaul sama sekali, no!</p>
                                        <p class="font-14">Kamu tahu istilah benefit of the doubt? Orang dengan Agreeableness tinggi akan memiliki keuntungan karena mereka akan lebih mudah untuk menerapkan hal tersebut: percaya kepada orang meskipun ragu.</p>
                                        <p class="font-14">Sementara orang dengan agreeableness rendah akan memiliki keuntungan karena mereka lebih mudah untuk assume the worst: berasumsi yang terburuk.</p>
                                        <p class="font-14">Orang dengan agreeableness akan memproses informasi tentang orang lain berdasarkan data dan analisa logis. Jadi, walaupun skor Agreeableness-mu rendah, bukan berarti kamu gak bisa bergaul, hanya saja, caranya agak berbeda dengan orang yang memiliki Agreeableness tinggi.</p>
                                        <p class="font-14">Lalu, apa untungnya mengetahui skor Agreeableness-mu?</p>
                                        <p class="font-14">Kamu bisa menggunakan informasi tersebut untuk membaca dirimu sendiri dan orang lain. Kamu dapat menerka apakah orang lain itu cocok sama kamu, apakah Agreeableness mereka tinggi atau rendah berdasarkan informasi yang kamu tahu tentang dirimu sendiri, dan kamu juga bisa tahu apa yang harus kamu pelajari dengan ekstra jika skor Agreeableness-mu rendah/tinggi.</p>
                                        
                                        <h5>Neuroticism</h5>
                                        <p class="font-14">Neuroticism disebut sebagai aspek yang paling memengaruhi aspek lainnya dalam kepribadianmu. Secara umum, Neuroticism merujuk pada dua hal, anxiety (ketidakstabilan dan rawan akan stress) serta one’s well-being (keamanan personal dan depresi).</p>
                                        <p class="font-14">Oleh karena itu, informasi mengenai seberapa tinggi skor Neuroticism kamu itu penting, karena neuroticism tinggi berarti kamu akan lebih gampang memiliki emosi yang gak stabil serta bad mood yang berkepanjangan (we don’t want that, do we?).</p>
                                        <p class="font-14">Ketika kamu sudah tahu bahwa Neuroticism-mu tinggi atau rendah, kamu akan lebih mudah untuk mengurangi hal-hal yang membuatmu menderita. Misalnya, ketika kamu memiliki Neuroticism tinggi, kamu akan merasa kurang cocok sama orang yang “kayak batu”; yang kalo nonton film sedih gak nangis, yang kalo ada kucing disiksa gak kasian banget, dll.</p>
                                        <p class="font-14">Di satu sisi, kamu memiliki kemampuan untuk merasakan emosi yang baik, namun di sisi lain kamu kurang handal dalam mengatasi gejolak perubahan emosi tersebut.</p>
                                        <p class="font-14">Sama halnya dengan neuroticism rendah, kamu akan lebih mudah untuk memiliki emosi stabil. Tapi tidak berarti Neuroticism rendah = selalu happy.  Kamu harus tahu apa yang membuatmu tenang dan apa yang membuatmu resah, that way it’ll be easier to control our emotions.</p>
                                        
                                        <h3>OCEAN Test: What’s Next?</h3>
                                        <p class="font-14">Setelah membaca tulisanku di atas, aku harap kamu bisa menggunakan hasil tes OCEAN-mu sebagai motivasi untuk berkembang! Kamu sudah tahu ‘plus minus’ dirimu, sekarang tinggal menunggu kamu bergerak untuk memanfaatkannya agar kamu bisa berkembang menjadi manusia yang lebih baik.</p>
                                        <p class="font-14">Eh, belum tes OCEAN? Tenang, kamu bisa sekalian dapet fasilitas itu kalau mendaftar layanan online mentoring-nya Satu Persen! Udah dapet partner curhat yang bisa dipercaya, dibimbing untuk mengenali diri kamu sendiri, dikasih worksheet biar bisa membantu dalam memantau perkembangan, dan tentunya dapet fasilitas tes-tes psikologi untuk bisa lebih akurat dalam memahami diri.</p>
                                        <p class="font-14">Banyak banget kan benefitnya? Coba cek dulu nih benefit lainnya dan teknis gimana caranya ikutan online mentoring bareng mentor Satu Persen dengan klik gambar di bawah ini!</p>
                                        
                                        <p class="font-14">Akhir kata, semoga tulisanku ini berguna, ya!</p>

                                        <h6>References</h6>
                                        <p class="font-14">Judge, T. A., Higgins, C. A., Thoresen, C. J., & Barrick, M. R. (1999). THE BIG FIVE PERSONALITY TRAITS, GENERAL MENTAL ABILITY, AND CAREER SUCCESS ACROSS THE LIFE SPAN. PERSONNEL PSYCHOLOGY, 621-652.</p>
                                        <p class="font-14">Mind Tools Content Team. (n.d). The Big Five Personality Traits Model and Test. Retrieved from MindTools: https://www.mindtools.com/pages/article/newCDV_22.htm</p>
                                        <p class="font-14">Dilansir dari https://satupersen.net/blog/interpretasi-tes-ocean</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
