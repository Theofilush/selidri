<div class="wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-sm-12">
                        <div style="margin: 10px;">
                            <?php echo $this->session->flashdata('notification_password')?>
                        </div>
                    </div>
                </div>
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h4 class="page-title m-0">Tes Big Five 1</h4>
                                </div>
                                <div class="col-md-4">
                                    <div class="float-right d-none d-md-block">
                                        <!-- <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-settings mr-1"></i> Settings
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Separated link</a>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

                <!-- <div class="row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-primary mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Orders</h6>
                                    <h4 class="mb-3 mt-0 float-right">1,587</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +11% </span> <span class="ml-2">From previous period</span>
                                </div>
                                
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-cube-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1447</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-info mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Revenue</h6>
                                    <h4 class="mb-3 mt-0 float-right">$46,785</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-danger"> -29% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-buffer h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : $47,596</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-pink mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Average Price</h6>
                                    <h4 class="mb-3 mt-0 float-right">15.9</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-primary"> 0% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-tag-text-outline h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 15.8</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card bg-success mini-stat text-white">
                            <div class="p-3 mini-stat-desc">
                                <div class="clearfix">
                                    <h6 class="text-uppercase mt-0 float-left text-white-50">Product Sold</h6>
                                    <h4 class="mb-3 mt-0 float-right">1890</h4>
                                </div>
                                <div>
                                    <span class="badge badge-light text-info"> +89% </span> <span class="ml-2">From previous period</span>
                                </div>
                            </div>
                            <div class="p-3">
                                <div class="float-right">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-briefcase-check h5"></i></a>
                                </div>
                                <p class="font-14 m-0">Last : 1776</p>
                            </div>
                        </div>
                    </div>
                </div>   -->
                <!-- end row -->

                <div class="row">
                    <div class="col-xl-8">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="mt-0 ">Tes OCEAN: The Big Five Personality</h3>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div style="text-align:center;margin: 20px;">
                                            <img src="<?php echo base_url() ?>assets/images/ocean1.png" alt="holland1" style="height:20vw;">
                                        </div>
                                        <p class="font-14">Kalian pasti sering denger soal tes kepribadian kayak MBTI. Nah, tapi pernah gak denger yang namanya OCEAN?</p>
                                        <p class="font-14">Beberapa dari kalian mungkin udah pernah denger, atau mungkin udah pernah dapat hasil Tes OCEAN. Ngapain sih, Tes OCEAN itu?</p>
                                        <p class="font-14">Gini, biar sederhana ya. Pernah gak kamu pas lagi ngerjain sesuatu project, misalnya. Kamu merasa skill dan kompetensimu tuh cukup, tapi kayak gak cocok aja gitu sama lingkungan project-nya. Kayak gak fit in sama dirimu.</p>
                                        <p class="font-14">Mungkin kamu yang rame dan asik lagi kedapatan kerjaan yang butuh banyak konsentrasi dan waktu tenang.  Mungkin juga kamu yang orangnya spontan tiba-tiba dapat kerjaan yang mengharuskan kamu mengatur jadwal sampe detail banget.</p>
                                        <p class="font-14">Gak kamu banget, deh, pokoknya. Pernah gak kamu ngerasa seperti itu?Nah, bisa jadi, lingkunganmu itu bertolak belakang sama kepribadianmu.</p>
                                        <p class="font-14">Di sinilah peran tes OCEAN atau yang biasa dikenal dengan Big Five Personality Traits sebagai ‘alat ukur’ kepribadian dibutuhkan.</p>
                                        <p class="font-14">Apa aja sih, yang diukur di tes OCEAN ini? Yuk kita bahas satu per satu!</p>

                                        <h3>OCEAN: Openness, Conscientiousness, Extroversion, Agreeableness, Neuroticis</h3>
                                        <p class="font-14">Keren gak tuh, singkatannya. Tiap poin dari Big Five Personality Traits ini merupakan sebuah spektrum dengan dua ujung ekstrim.</p>
                                        <p class="font-14">Misalnya poin extroversion merupakan spektrum dengan ujung extreme introversion dan extreme extroversion. Simple-nya, introvert banget dan extrovert banget, dan kamu berada somewhere along this spectrum.</p>
                                        <p class="font-14">Lewis Goldberg merupakan orang yang memberikan nama “The Big Five” pada jenis tes kepribadian ini; sekarang OCEAN merupakan tes yang dianggap akurat dan sering dipakai oleh perusahaan-perusahaan untuk mengetahui kepribadian calon karyawannya.</p>
                                        
                                        <p class="font-14">Oke, cukup basa-basinya, let’s get into work!</p>
                                        
                                        <h5>O: Openness</h5>
                                        <p class="font-14">Openness atau bahasa indonesianya ‘keterbukaan’ berarti seberapa terbuka kamu terhadap hal-hal baru. Mau itu pengetahuan, pengalaman, sosok orang, ataupun kesempatan baru, orang dengan skor Openness yang tinggi lebih cenderung untuk penasaran terhadap hal-hal tersebut.</p>
                                        <p class="font-14">Namun, bukan berarti orang yang skornya rendah lantas menjadi kolot dan menolak hal baru. Mereka hanya lebih konsisten dan waspada terhadap perubahan dan hal-hal baru yang ada di sekitar mereka.</p>
                                        <p class="font-14">Ngomong-ngomong soal ini, kamu pernah gak ngeliat temenmu yang jiwa petualangnya tinggi banget, terus kamu penasaran, kok bisa ya dia kayak gitu? Kira-kira turunan atau gimana tuh?</p>
                                        <p class="font-14">Ternyata, sah-sah aja kalo kamu ngomong itu turunan, karena sifat-sifat kita semua tuh ada yang berasal dari keturunan, ada yang berasal dari lingkungan. Jadi mungkin sekarang kamu bisa cari tahu kira-kira sifat apa yang kamu dapat dari orang tuamu, hehe.</p>
                                        
                                        <h5>C: Conscientiousness</h5>
                                        <p class="font-14">Conscientiousness adalah soal seberapa terorganisirnya seseorang. Kalau kamu lebih enjoy mengerjakan sesuatu dengan jadwal teratur, planning yang ketat jauh sebelum hari-H, atau kamu lebih nyaman dan suka dengan lingkungan kerja yang teratur, bisa jadi skor kamu di conscientiousness ini tinggi.</p>
                                        <p class="font-14">Jangan berkecil hati bagi kamu yang skor Conscientiousness-nya rendah, karena itu gak berarti kamu orangnya ‘semrawut’ dan ceroboh, bisa aja kamu tipe orang yang spontan.</p>
                                        <p class="font-14">Orang dengan skor Conscientiousness tinggi juga lebih cenderung untuk gak prokrastinasi karena mereka bergerak dengan goal-oriented mindset. Hm, kayaknya skor conscientiousness-ku rendah deh. Kalau kamu gimana?</p>
                                        
                                        <h5>E: Extroversion</h5>
                                        <p class="font-14">Kalau yang ini kayaknya udah cukup jelas ya. Apakah kamu menikmati berada dalam kerumunan orang? Seberapa sociable-kah dirimu? Sejauh mana kamu menikmati dealing with people?</p>
                                        <p class="font-14">Skor Extroversion kamu akan menunjukkan apakah kamu lebih ke arah introvert atau extrovert. Dua hal ini sering banget, loh dibahas orang-orang, dan kadang sering terjadi miskonsepsi.</p>
                                        <p class="font-14">Perlu kamu ingat bahwa extrovert gak selalu lebih baik dari introvert. Kalau kamu adalah seorang yang introvert, cintailah hal tersebut! Jangan memaksakan diri untuk fit in like the cool kids hanya karena mereka terlihat lebih ‘menyenangkan’. Be yourself!</p>
                                        
                                        <h5>A: Agreeableness</h5>
                                        <p class="font-14">Kalau yang ini tuh soal seberapa baik kamu bisa berinteraksi dengan seseorang. Kemampuan berempati, berkompromi, menolong orang lain, dsb. rata-rata dimiliki oleh orang dengan skor Agreeableness yang tinggi. Simply put, apakah kamu lebih kooperatif dibanding orang lain?</p>
                                        <p class="font-14">Kalau kamu memiliki Agreeableness yang rendah, kamu mungkin akan mendapati dirimu lebih mudah untuk meragukan orang lain dikarenakan sifat naturalmu untuk berpikir, ‘orang ini ada maunya gak sih?’.</p>
                                        <p class="font-14">Orang dengan skor Agreeableness rendah akan merasa kesulitan untuk mengerti orang lain. Jangan khawatir, dengan mengetahui bahwa kamu memiliki agreeableness yang rendah, kamu dapat menjadikan itu dorongan untuk belajar lagi bagaimana untuk bisa lebih mengerti orang lain.</p>
                                        <p class="font-14">Kalau kamu merasa kesulitan untuk membaca dirimu sendiri atau orang lain, aku punya video yang tepat untukmu.</p>

                                            <div class="embed-responsive embed-responsive-16by9">
                                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/jnwOBr7DtKA?feature=oembed"></iframe>
                                            </div> 
                                            <div class="m-b-30" style="text-align:center;">Tes Holland atau Tes Big FIve atau OCEAN</div>
                                            
                                        <h5>N: Neuroticism</h5>
                                        <p class="font-14">Neuroticism adalah seberapa emosional seseorang menghadapi situasi. Jika kamu merasa dirimu adalah seseorang yang moody, yang gampang sedih, kesal, dsb., mungkin kamu memiliki neuroticism yang tinggi.</p>
                                        <p class="font-14">Orang dengan Neuroticism tinggi lebih mudah untuk mengalami ketidakstabilan emosi. Gampang marah, gampang sedih, gampang panik, dll.</p>
                                        <p class="font-14">Sebaliknya, neuroticism rendah berarti orang tersebut lebih tenang, lebih bisa mengatur emosinya. Orang dengan Neuroticism tinggi juga lebih sering khawatir atau overthink about something.</p>
                                        <p class="font-14">Maka dari itu, bagi kamu yang merasa Neuroticism tinggi, atau sekadar sadar bahwa dirimu worries a lot, aku rasa penting untuk tahu apa yang membuatmu khawatir serta apa yang membuatmu tenang.</p>
                                        <p class="font-14">That way, you can have more control of your own emotion. Emotional Intelligence yang baik juga bisa membantumu untuk mengatur emosi dalam dirimu dengan lebih baik.</p>
                                        
                                        <h3>OCEAN Clear! What’s Next</h3>
                                        <p class="font-14">Kira-kira begitulah penjelasan singkat tentang masing-masing poin dari OCEAN atau Big Five Personality Trait. Kamu udah pernah coba belum Tes OCEAN? Aku sendiri sudah beberapa kali mengambil Tes OCEAN kecil-kecilan, dan hasilnya gak jauh berbeda satu sama lain.</p>
                                        <p class="font-14">Hal yang perlu kamu ingat: setiap poin dari Tes OCEAN adalah spektrum dengan dua ujung ekstrim. Kamu harus bisa membaca hasil Tes OCEAN-mu dan berpikir langkah-langkah apa yang dapat kamu lakukan untuk mengembangkan hidupmu lebih baik lagi berdasarkan kepribadianmu.</p>
                                        <p class="font-14">Kamu juga harus ingat bahwa hanya karena kamu memiliki kepribadian yang gak masuk pada stereotip orang pada umumnya (contohnya kamu introvert tapi sangat cerewet dan memiliki agreeableness yang tinggi atau extrovert yang gak banyak bicara), bukan berarti kamu aneh dan harus mengubah dirimu.</p>
                                        <p class="font-14">Instead, ketahuilah benar-benar kualitas dirimu dan gunakan hal tersebut untuk thrive in life! Akhir kata, semoga tulisanku ini berguna ya!</p>
                                        
                                        <h6>Reference</h6>
                                        <p class="font-14">Cherry, K. (2020, July 13). The Big Five Personality Traits. Retrieved from verywellmind: https://www.verywellmind.com/the-big-five-personality-dimensions-2795422</p>
                                        <p class="font-14">Mind Tools Content Team. (n.d). The Big Five Personality Traits Model and Test. Retrieved from MindTools: https://www.mindtools.com/pages/article/newCDV_22.htm</p>
                                        <p class="font-14">Science of People. (n.d). Take Our Free Personality Quiz and See Where You Rank for the Big 5 Traits. Retrieved from Science of People.</p>
                                        <p class="font-14">Thiel, E. v. (2020, February 11). Big Five personality test traits. Retrieved from 123test: https://www.123test.com/big-five-personality-theory/</p>
                                        <p class="font-14">Dilansir dari https://satupersen.net/blog/tes-ocean-adalah</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>